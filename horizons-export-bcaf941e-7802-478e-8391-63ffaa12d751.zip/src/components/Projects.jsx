
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const projects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    description: 'A fully responsive e-commerce platform with product filtering, cart functionality, and secure checkout process.',
    tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    image: 'e-commerce-platform',
    imageAlt: 'E-commerce website showing product grid and shopping cart',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: true
  },
  {
    id: 2,
    title: 'Task Management App',
    description: 'A productivity application that helps users organize tasks, set priorities, and track progress with intuitive UI.',
    tags: ['React', 'Firebase', 'Tailwind CSS'],
    image: 'task-management-app',
    imageAlt: 'Task management application with kanban board interface',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: true
  },
  {
    id: 3,
    title: 'Financial Dashboard',
    description: 'Interactive dashboard for visualizing financial data with real-time updates and customizable widgets.',
    tags: ['React', 'D3.js', 'Express', 'PostgreSQL'],
    image: 'financial-dashboard',
    imageAlt: 'Financial dashboard with charts, graphs and data visualization',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: true
  },
  {
    id: 4,
    title: 'Social Media Platform',
    description: 'A social networking application with real-time messaging, post sharing, and user profiles.',
    tags: ['React', 'Socket.io', 'MongoDB', 'Express'],
    image: 'social-media-platform',
    imageAlt: 'Social media application showing user profiles and post feed',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: false
  },
  {
    id: 5,
    title: 'Weather Application',
    description: 'A weather forecasting app that provides real-time weather data and 7-day forecasts for any location.',
    tags: ['React', 'OpenWeather API', 'Geolocation'],
    image: 'weather-application',
    imageAlt: 'Weather application showing forecast with temperature and conditions',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: false
  },
  {
    id: 6,
    title: 'Recipe Finder',
    description: 'An application that helps users discover recipes based on available ingredients and dietary preferences.',
    tags: ['React', 'Spoonacular API', 'Tailwind CSS'],
    image: 'recipe-finder',
    imageAlt: 'Recipe finder application showing food images and ingredient lists',
    liveLink: 'https://example.com',
    githubLink: 'https://github.com',
    featured: false
  }
];

const Projects = () => {
  const [showAll, setShowAll] = useState(false);
  
  const displayedProjects = showAll 
    ? projects 
    : projects.filter(project => project.featured);
  
  const fadeInUpVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (custom) => ({
      opacity: 1,
      y: 0,
      transition: { delay: custom * 0.1, duration: 0.5 }
    })
  };

  return (
    <div className="py-20 md:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={fadeInUpVariants}
          custom={0}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">My Projects</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore my recent work and projects that showcase my skills and expertise in web development.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedProjects.map((project, index) => (
            <motion.div
              key={project.id}
              className="group bg-card rounded-xl overflow-hidden border border-border shadow-sm card-hover"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={fadeInUpVariants}
              custom={index + 1}
            >
              <div className="relative overflow-hidden aspect-video">
                <img  
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                  alt={project.imageAlt}
                 src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4 flex gap-3">
                    <a 
                      href={project.liveLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-primary text-primary-foreground p-2 rounded-full hover:bg-primary/90 transition-colors"
                    >
                      <ExternalLink size={18} />
                    </a>
                    <a 
                      href={project.githubLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-card text-card-foreground p-2 rounded-full hover:bg-muted transition-colors"
                    >
                      <Github size={18} />
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, i) => (
                    <span 
                      key={i} 
                      className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <a 
                  href={project.liveLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                >
                  View Project <ArrowRight size={16} className="ml-1" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
        
        {!showAll && projects.length > 3 && (
          <motion.div 
            className="text-center mt-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUpVariants}
            custom={4}
          >
            <Button 
              onClick={() => setShowAll(true)}
              variant="outline"
              size="lg"
              className="rounded-full"
            >
              View All Projects <ArrowRight size={16} className="ml-2" />
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Projects;
